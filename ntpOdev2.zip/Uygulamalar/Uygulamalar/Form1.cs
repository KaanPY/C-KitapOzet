﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Uygulamalar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte team = Convert.ToByte(textBox1.Text), team2 = Convert.ToByte(textBox2.Text);

            if(team > team2)
            {
                MessageBox.Show("1. Takım Kazandı!", "Kazanan", MessageBoxButtons.OK);
            }
            else if(team < team2) 
            {
                MessageBox.Show("2. Takım Kazandı!", "Kazanan", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Berabere!", "Kazanan", MessageBoxButtons.OK);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            byte age = Convert.ToByte(textBox3.Text);

            if(age >= 18)
            {
                MessageBox.Show("Ehliyet Alabilirsiniz!", "Ehliyet Yaş Sınırı", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Ehliyet Alamazsınız!", "Ehliyet Yaş Sınırı", MessageBoxButtons.OK);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            byte number = Convert.ToByte(textBox4.Text), number2 = Convert.ToByte(textBox5.Text);

            if(number > number2)
            {
                MessageBox.Show("1. Sayı 2. Sayıdan Büyüktür!", "Büyük Sayı Bulucu", MessageBoxButtons.OK);
            }
            else if(number < number2)
            {
                MessageBox.Show("2. Sayı 1. Sayıdan Büyüktür!", "Büyük Sayı Bulucu", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Sayılar Eşittir!", "Büyük Sayı Bulucu", MessageBoxButtons.OK);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int number3 = Convert.ToInt32(textBox6.Text);

            if (number3 > 0)
            {
                if (number3 % 2 == 0)
                {
                    MessageBox.Show(number3.ToString() + " Sayısı Çifttir!", "Tek mi? Çift mi?", MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show(number3.ToString() + " Sayısı Tektir!", "Tek mi? Çift mi?", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Sayı Sıfırdan Büyük Olmalıdır!", "HATA!", MessageBoxButtons.OK);
            }
        }
    }
}
