﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace alfabeninKacinciHarfi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            char harf = Convert.ToChar(comboBox1.Text);
    
                switch (harf)
                {
                    case 'A':
                        label1.Text = "A harfi, alfabenin 1. harfidir.";
                        break;
                    case 'B':
                        label1.Text = "B harfi, alfabenin 2. harfidir.";
                        break;
                    case 'C':
                        label1.Text = "C harfi, alfabenin 3. harfidir.";
                        break;
                    case 'Ç':
                        label1.Text = "Ç harfi, alfabenin 4. harfidir.";
                        break;
                    case 'D':
                        label1.Text = "D harfi, alfabenin 5. harfidir.";
                        break;
                    case 'E':
                        label1.Text = "E harfi, alfabenin 6. harfidir.";
                        break;
                    case 'F':
                        label1.Text = "F harfi, alfabenin 7. harfidir.";
                        break;
                    case 'G':
                        label1.Text = "G harfi, alfabenin 8. harfidir.";
                        break;
                    case 'Ğ':
                        label1.Text = "Ğ harfi, alfabenin 9. harfidir.";
                        break;
                    case 'H':
                        label1.Text = "H harfi, alfabenin 10. harfidir.";
                        break;
                    case 'I':
                        label1.Text = "I harfi, alfabenin 11. harfidir.";
                        break;
                    case 'İ':
                        label1.Text = "İ harfi, alfabenin 12. harfidir.";
                        break;
                    case 'J':
                        label1.Text = "J harfi, alfabenin 13. harfidir.";
                        break;
                    case 'K':
                        label1.Text = "K harfi, alfabenin 14. harfidir.";
                        break;
                    case 'L':
                        label1.Text = "L harfi, alfabenin 15. harfidir.";
                        break;
                    case 'M':
                        label1.Text = "M harfi, alfabenin 16. harfidir.";
                        break;
                    case 'N':
                        label1.Text = "N harfi, alfabenin 17. harfidir.";
                        break;
                    case 'O':
                        label1.Text = "O harfi, alfabenin 18. harfidir.";
                        break;
                    case 'Ö':
                        label1.Text = "Ö harfi, alfabenin 19. harfidir.";
                        break;
                    case 'P':
                        label1.Text = "P harfi, alfabenin 20. harfidir.";
                        break;
                    case 'R':
                        label1.Text = "R harfi, alfabenin 21. harfidir.";
                        break;
                    case 'S':
                        label1.Text = "S harfi, alfabenin 22. harfidir.";
                        break;
                    case 'Ş':
                        label1.Text = "Ş harfi, alfabenin 23. harfidir.";
                        break;
                    case 'T':
                        label1.Text = "T harfi, alfabenin 24. harfidir.";
                        break;
                    case 'U':
                        label1.Text = "U harfi, alfabenin 25. harfidir.";
                        break;
                    case 'Ü':
                        label1.Text = "Ü harfi, alfabenin 26. harfidir.";
                        break;
                    case 'V':
                        label1.Text = "V harfi, alfabenin 27. harfidir.";
                        break;
                    case 'Y':
                        label1.Text = "Y harfi, alfabenin 28. harfidir.";
                        break;
                    case 'Z':
                        label1.Text = "Z harfi, alfabenin 29. harfidir.";
                        break;
                    default:
                        MessageBox.Show("Alfabede olmayan bir karakter girdiniz!", "HATA!", MessageBoxButtons.OK);
                        break;
                }      
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
