﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace uygulamalar2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Değişken tanımlamadım çünkü; girilen her verinin metinsel yani string veri türü olmasından dolayı. 

            if(textBox1.Text == "kaan@turktelekom.com")
            {
                MessageBox.Show("Giriş Başarılı!", "Giriş Sistemi", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Giriş Başarısız!", "Giriş Sistemi", MessageBoxButtons.OK);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            if(checkBox1.Checked == true)
            {
                listBox1.Items.Add("Lamba: Açık");
            }
            else
            {
                listBox1.Items.Add("Lamba: Kapalı");
            }

            if(checkBox2.Checked == true)
            {
                listBox1.Items.Add("Kombi: Açık");
            }
            else
            {
                listBox1.Items.Add("Kombi: Kapalı");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int number = Convert.ToInt32(textBox2.Text), number2 = Convert.ToInt32(textBox3.Text);

            if(radioButton1.Checked == true)
            {
                MessageBox.Show("Seçilen İşlem: Toplama\nSonuç: " + (number + number2).ToString(), "Hesap Makinesi", MessageBoxButtons.OK);
            }
            else if(radioButton2.Checked == true)
            {
                MessageBox.Show("Seçilen İşlem: Çıkartma\nSonuç: " + (number - number2).ToString(), "Hesap Makinesi", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Lütfen Bir İşlem Seçiniz!", "HATA!", MessageBoxButtons.OK);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            byte not1 = Convert.ToByte(textBox4.Text);

            if(not1 <= 0)
            {
                MessageBox.Show("Not Sıfırdan Büyük Olmalıdır!", "Not Sistemi", MessageBoxButtons.OK);
            }
            else if(not1 < 25)
            {
                MessageBox.Show("Notunuz 0", "Not Sistemi", MessageBoxButtons.OK);
            }
            else if (not1 < 45)
            {
                MessageBox.Show("Notunuz 1", "Not Sistemi", MessageBoxButtons.OK);
            }
            else if (not1 < 55)
            {
                MessageBox.Show("Notunuz 2", "Not Sistemi", MessageBoxButtons.OK);
            }
            else if (not1 < 70)
            {
                MessageBox.Show("Notunuz 3", "Not Sistemi", MessageBoxButtons.OK);
            }
            else if (not1 < 85)
            {
                MessageBox.Show("Notunuz 4", "Not Sistemi", MessageBoxButtons.OK);
            }
            else if (not1 <= 100)
            {
                MessageBox.Show("Notunuz 5", "Not Sistemi", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Lütfen 1 - 100 Arası Sayı Giriniz!", "HATA!", MessageBoxButtons.OK);
            }
        }
    }
}
